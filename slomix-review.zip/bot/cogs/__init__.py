"""
Bot Cogs Module
Modular command groups for the bot
"""

# This makes it a proper Python package
