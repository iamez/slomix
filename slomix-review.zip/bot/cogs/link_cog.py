"""
Link Cog - Player-Discord Account Linking
==========================================
Extracted from: bot/ultimate_bot.py (Phase 2 - Cog Extraction)
Extraction Date: 2025-11-01

Player linking system connecting Discord accounts to in-game profiles (GUIDs).
Supports smart self-linking, name search, GUID direct linking, and admin linking.

Commands:
- !link - Smart self-linking with top 3 suggestions
- !link <name> - Search by player name
- !link <GUID> - Direct link by GUID
- !link @user <GUID> - Admin link another user
- !unlink - Remove your link
- !select <1-3> - Alternative to reaction selection
- !find_player <name> - Helper: Search for players with GUIDs and aliases (NEW!)
- !list_players - Browse all players with pagination

Enhanced Features:
- Interactive reactions (1️⃣/2️⃣/3️⃣) for easy selection
- Shows up to 3 aliases per player
- GUID validation and confirmation
- Admin linking with permissions check
- Fuzzy name matching
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional

import discord
import aiosqlite
from discord.ext import commands

logger = logging.getLogger(__name__)


class LinkCog(commands.Cog, name="Link"):
    """🔗 Player-Discord Account Linking"""

    def __init__(self, bot):
        """
        Initialize the Link Cog.

        Args:
            bot: The main bot instance with database access
        """
        self.bot = bot
        logger.info("🔗 LinkCog loaded")

    async def _ensure_player_name_alias(self, db: "aiosqlite.Connection") -> None:
        """Create TEMP VIEW aliasing for player_name column compatibility."""
        try:
            cursor = await db.execute("PRAGMA table_info(player_comprehensive_stats)")
            columns = await cursor.fetchall()
            column_names = [col[1] for col in columns]

            if "player_name" not in column_names:
                await db.execute("""
                    CREATE TEMP VIEW IF NOT EXISTS player_comprehensive_stats_view AS
                    SELECT *, name AS player_name FROM player_comprehensive_stats
                """)
                logger.debug("Created temporary player_name alias view")
        except Exception as e:
            logger.warning(f"Could not create player_name alias: {e}")

    @commands.command(name="list_players", aliases=["players", "lp"])
    async def list_players(self, ctx, filter_type: str = None, page: int = 1):
        """
        👥 List all players with pagination.

        Browse all players in the database with stats, link status, and activity.
        Supports filtering and pagination for easy navigation.

        Usage:
            !list_players              → Show all players (page 1)
            !list_players 2            → Show page 2
            !list_players linked       → Show only linked players
            !list_players unlinked     → Show only unlinked players
            !list_players active       → Show players from last 30 days
            !list_players linked 2     → Show linked players, page 2

        Args:
            filter_type: Optional filter (linked/unlinked/active)
            page: Page number (default: 1, 15 players per page)

        Returns:
            Embed showing players with:
            - Link status icon (🔗 linked / ❌ unlinked)
            - Player name, sessions, kills/deaths, K/D ratio
            - Last played date (relative)
            - Navigation footer with page numbers
        """
        try:
            async with aiosqlite.connect(self.bot.db_path) as db:
                # Base query to get all players with their link status
                base_query = """
                    SELECT 
                        p.player_guid,
                        p.player_name,
                        pl.discord_id,
                        COUNT(DISTINCT p.session_date) as sessions_played,
                        MAX(p.session_date) as last_played,
                        SUM(p.kills) as total_kills,
                        SUM(p.deaths) as total_deaths
                    FROM player_comprehensive_stats p
                    LEFT JOIN player_links pl ON p.player_guid = pl.et_guid
                    GROUP BY p.player_guid, p.player_name, pl.discord_id
                """

                # Handle case where user passed page as first arg (e.g., !lp 2)
                if filter_type and filter_type.isdigit():
                    page = int(filter_type)
                    filter_type = None

                # Apply filter
                filter_clause = ""
                if filter_type:
                    filter_lower = filter_type.lower()
                    if filter_lower in ["linked", "link"]:
                        filter_clause = " HAVING pl.discord_id IS NOT NULL"
                    elif filter_lower in ["unlinked", "nolink"]:
                        filter_clause = " HAVING pl.discord_id IS NULL"
                    elif filter_lower in ["active", "recent"]:
                        filter_clause = " HAVING MAX(p.session_date) >= date('now', '-30 days')"

                final_query = base_query + filter_clause + " ORDER BY sessions_played DESC, total_kills DESC"

                async with db.execute(final_query) as cursor:
                    players = await cursor.fetchall()

            if not players:
                await ctx.send(
                    f"❌ No players found" + (f" with filter: {filter_type}" if filter_type else "")
                )
                return

            # Count linked vs unlinked
            linked_count = sum(1 for p in players if p[2])
            unlinked_count = len(players) - linked_count

            # Pagination settings
            players_per_page = 15
            total_pages = (len(players) + players_per_page - 1) // players_per_page

            # Validate page number
            if page < 1:
                page = 1
            elif page > total_pages:
                page = total_pages

            start_idx = (page - 1) * players_per_page
            end_idx = min(start_idx + players_per_page, len(players))
            page_players = players[start_idx:end_idx]

            # Create embed
            filter_text = f" - {filter_type.upper()}" if filter_type else ""
            embed = discord.Embed(
                title=f"👥 Players List{filter_text}",
                description=(
                    f"**Total**: {len(players)} players • "
                    f"🔗 {linked_count} linked • ❌ {unlinked_count} unlinked\n"
                    f"**Page {page}/{total_pages}** (showing {start_idx+1}-{end_idx})"
                ),
                color=discord.Color.green(),
            )

            # Format player list (compact single-line per player)
            player_lines = []
            for (
                guid,
                name,
                discord_id,
                sessions,
                last_played,
                kills,
                deaths,
            ) in page_players:
                link_icon = "🔗" if discord_id else "❌"
                kd = kills / deaths if deaths > 0 else kills

                # Format last played date compactly
                try:
                    last_date = datetime.fromisoformat(
                        last_played.replace("Z", "+00:00") if "Z" in last_played else last_played
                    )
                    days_ago = (datetime.now() - last_date).days
                    if days_ago == 0:
                        last_str = "today"
                    elif days_ago == 1:
                        last_str = "1d"
                    elif days_ago < 7:
                        last_str = f"{days_ago}d"
                    elif days_ago < 30:
                        last_str = f"{days_ago//7}w"
                    else:
                        last_str = f"{days_ago//30}mo"
                except Exception:
                    last_str = "?"

                player_lines.append(
                    f"{link_icon} **{name[:20]}** • "
                    f"{sessions}s • {kills}K/{deaths}D ({kd:.1f}) • {last_str}"
                )

            embed.add_field(
                name=f"Players {start_idx+1}-{end_idx}",
                value="\n".join(player_lines),
                inline=False,
            )

            # Navigation footer
            nav_text = ""
            if total_pages > 1:
                if page > 1:
                    prev_cmd = f"!lp {filter_type or ''} {page-1}".strip()
                    nav_text += f"⬅️ `{prev_cmd}` • "
                nav_text += f"Page {page}/{total_pages}"
                if page < total_pages:
                    next_cmd = f"!lp {filter_type or ''} {page+1}".strip()
                    nav_text += f" • `{next_cmd}` ➡️"

            if nav_text:
                embed.set_footer(text=nav_text)
            else:
                embed.set_footer(
                    text="Use !link to link • !list_players [linked|unlinked|active]"
                )

            await ctx.send(embed=embed)

        except Exception as e:
            logger.error(f"Error in list_players command: {e}", exc_info=True)
            await ctx.send(f"❌ Error listing players: {e}")

    @commands.command(name="find_player", aliases=["findplayer", "fp", "search_player"])
    async def find_player(self, ctx, *, search_term: str):
        """
        🔍 Find players by name with GUIDs and aliases (Helper for linking).

        This command helps admins and users find the exact GUID and aliases
        for a player they want to link. Shows up to 5 matches with full details.

        Usage:
            !find_player <name>
            !fp <name>

        Args:
            search_term: Player name or partial name to search for

        Example:
            !find_player john
            → Shows all players with "john" in their name/aliases
            → Displays GUID, top 3 aliases, stats, last seen

        Returns:
            Embed with up to 5 matching players showing:
            - GUID (for !link command)
            - Top 3 aliases
            - Stats (kills/deaths/K/D/games)
            - Last seen date
            - Link status (linked/unlinked)
        """
        try:
            async with aiosqlite.connect(self.bot.db_path) as db:
                # Search in player_aliases (uses 'guid' and 'alias' columns)
                async with db.execute(
                    """
                    SELECT DISTINCT pa.guid
                    FROM player_aliases pa
                    WHERE LOWER(pa.alias) LIKE LOWER(?)
                    ORDER BY pa.last_seen DESC
                    LIMIT 10
                """,
                    (f"%{search_term}%",),
                ) as cursor:
                    alias_guids = [row[0] for row in await cursor.fetchall()]

                # Also search main stats table
                async with db.execute(
                    """
                    SELECT DISTINCT player_guid
                    FROM player_comprehensive_stats
                    WHERE LOWER(player_name) LIKE LOWER(?)
                    ORDER BY session_date DESC
                    LIMIT 10
                """,
                    (f"%{search_term}%",),
                ) as cursor:
                    stats_guids = [row[0] for row in await cursor.fetchall()]

                # Combine and deduplicate
                guid_set = set(alias_guids + stats_guids)

                if not guid_set:
                    await ctx.send(
                        f"❌ No players found matching **'{search_term}'**\n\n"
                        f"💡 **Tips:**\n"
                        f"   • Try a shorter/partial name\n"
                        f"   • Use `!list_players` to browse all players\n"
                        f"   • Check spelling - search is case-insensitive"
                    )
                    return

                # Limit to 5 results for cleaner display
                guid_list = list(guid_set)[:5]

                # Build detailed results
                embed = discord.Embed(
                    title=f"🔍 Player Search Results: '{search_term}'",
                    description=f"Found **{len(guid_set)}** matching players (showing top {len(guid_list)})",
                    color=0x3498DB,
                )

                for guid in guid_list:
                    # Get stats
                    async with db.execute(
                        """
                        SELECT 
                            SUM(kills) as total_kills,
                            SUM(deaths) as total_deaths,
                            COUNT(DISTINCT session_id) as games,
                            MAX(session_date) as last_seen
                        FROM player_comprehensive_stats
                        WHERE player_guid = ?
                    """,
                        (guid,),
                    ) as cursor:
                        stats = await cursor.fetchone()

                    # Get top 3 aliases
                    async with db.execute(
                        """
                        SELECT alias, last_seen, times_seen
                        FROM player_aliases
                        WHERE guid = ?
                        ORDER BY last_seen DESC, times_seen DESC
                        LIMIT 3
                    """,
                        (guid,),
                    ) as cursor:
                        aliases = await cursor.fetchall()

                    # Get link status
                    async with db.execute(
                        """
                        SELECT discord_username
                        FROM player_links
                        WHERE et_guid = ?
                    """,
                        (guid,),
                    ) as cursor:
                        link_row = await cursor.fetchone()

                    # Format data
                    if aliases:
                        primary_name = aliases[0][0]
                        alias_list = [f"**{a[0]}**" for a in aliases]
                        alias_str = ", ".join(alias_list)
                        if len(aliases) < 3:
                            alias_str += " _(only known name)_" if len(aliases) == 1 else ""
                    else:
                        primary_name = "Unknown"
                        alias_str = "_(No aliases found)_"

                    if stats:
                        kills, deaths, games, last_seen = stats
                        kd = kills / deaths if deaths and deaths > 0 else (kills if kills else 0)
                        stats_str = f"**{kills:,}** K / **{deaths:,}** D / **{kd:.2f}** K/D\n**Games:** {games:,}"
                    else:
                        stats_str = "_(No stats found)_"
                        last_seen = "Never"

                    link_status = f"🔗 **Linked** to {link_row[0]}" if link_row else "❌ **Unlinked**"

                    # Calculate days ago for last_seen
                    try:
                        from datetime import datetime
                        last_date = datetime.fromisoformat(
                            last_seen.replace("Z", "+00:00") if "Z" in last_seen else last_seen
                        )
                        days_ago = (datetime.now() - last_date).days
                        if days_ago == 0:
                            last_str = "Today"
                        elif days_ago == 1:
                            last_str = "Yesterday"
                        elif days_ago < 7:
                            last_str = f"{days_ago} days ago"
                        elif days_ago < 30:
                            weeks = days_ago // 7
                            last_str = f"{weeks} week{'s' if weeks > 1 else ''} ago"
                        elif days_ago < 365:
                            months = days_ago // 30
                            last_str = f"{months} month{'s' if months > 1 else ''} ago"
                        else:
                            years = days_ago // 365
                            last_str = f"{years} year{'s' if years > 1 else ''} ago"
                    except Exception:
                        last_str = last_seen

                    # Add field to embed
                    embed.add_field(
                        name=f"🎮 {primary_name}",
                        value=(
                            f"**GUID:** `{guid}` _(use this for !link)_\n"
                            f"**Known as:** {alias_str}\n"
                            f"{stats_str}\n"
                            f"**Last Seen:** {last_str}\n"
                            f"**Status:** {link_status}"
                        ),
                        inline=False,
                    )

                # Add footer with usage hints
                embed.set_footer(
                    text=(
                        f"💡 To link: !link {guid_list[0]} | "
                        f"Admin link: !link @user {guid_list[0]} | "
                        f"Requested by {ctx.author.display_name}"
                    )
                )

                await ctx.send(embed=embed)

                # Log search for debugging
                logger.info(
                    f"🔍 Player search by {ctx.author}: '{search_term}' → {len(guid_set)} results"
                )

        except Exception as e:
            logger.error(f"Error in find_player command: {e}", exc_info=True)
            await ctx.send(
                f"❌ Error searching for players: {e}\n\n"
                f"💡 Try: `!list_players` to browse all players"
            )

    @commands.command(name="link")
    async def link(self, ctx, target: Optional[str] = None, *, guid: Optional[str] = None):
        """
        🔗 Link your Discord account to your in-game profile.

        Multiple usage modes with smart detection:

        **Self-Linking:**
        - `!link` → Smart search with top 3 suggestions (interactive)
        - `!link YourName` → Search by name (fuzzy matching)
        - `!link <GUID>` → Direct link by GUID (8 hex chars)

        **Admin Linking (requires Manage Server):**
        - `!link @user <GUID>` → Link another user's Discord to a GUID

        **Finding GUIDs:**
        - `!find_player <name>` → Search for players with full details

        Features:
        - Interactive selection with reactions (1️⃣/2️⃣/3️⃣)
        - Shows player stats, aliases, and last seen
        - Confirmation required for all links
        - Prevents duplicate links

        Examples:
            !link
            → Shows top 3 unlinked players

            !link john
            → Searches for players named "john"

            !link D8423F90
            → Links directly to GUID D8423F90 (with confirmation)

            !find_player john
            → Shows all "john" players with GUIDs and aliases

            !link @user D8423F90
            → Admin: Links @user to GUID D8423F90
        """
        try:
            # === SCENARIO 0: ADMIN LINKING (@mention + GUID) ===
            if ctx.message.mentions and guid:
                await self._admin_link(ctx, ctx.message.mentions[0], guid.upper())
                return

            # For self-linking
            discord_id = str(ctx.author.id)

            # Check if already linked
            async with aiosqlite.connect(self.bot.db_path) as db:
                async with db.execute(
                    """
                    SELECT et_name, et_guid FROM player_links
                    WHERE discord_id = ?
                """,
                    (discord_id,),
                ) as cursor:
                    existing = await cursor.fetchone()

                if existing:
                    await ctx.send(
                        f"⚠️ You're already linked to **{existing[0]}** (GUID: `{existing[1]}`)\n\n"
                        f"Use `!unlink` first to change your linked account.\n"
                        f"Use `!stats` to see your stats!"
                    )
                    return

                # === SCENARIO 1: NO ARGUMENTS - Smart Self-Linking ===
                if not target:
                    await self._smart_self_link(ctx, discord_id, db)
                    return

                # === SCENARIO 2: GUID Direct Link ===
                # Check if it's a GUID (8 hex characters)
                if len(target) == 8 and all(c in "0123456789ABCDEFabcdef" for c in target):
                    await self._link_by_guid(ctx, discord_id, target.upper(), db)
                    return

                # === SCENARIO 3: Name Search ===
                await self._link_by_name(ctx, discord_id, target, db)

        except Exception as e:
            logger.error(f"Error in link command: {e}", exc_info=True)
            await ctx.send(
                f"❌ Error linking account: {e}\n\n"
                f"💡 Try: `!find_player <name>` to search for players with GUIDs"
            )

    async def _smart_self_link(self, ctx, discord_id: str, db):
        """Smart self-linking: show top 3 unlinked GUIDs with aliases."""
        try:
            # Get top 3 unlinked players by recent activity and total stats
            async with db.execute(
                """
                SELECT 
                    player_guid,
                    MAX(session_date) as last_played,
                    SUM(kills) as total_kills,
                    SUM(deaths) as total_deaths,
                    COUNT(DISTINCT session_id) as games
                FROM player_comprehensive_stats
                WHERE player_guid NOT IN (
                    SELECT et_guid FROM player_links WHERE et_guid IS NOT NULL
                )
                GROUP BY player_guid
                ORDER BY last_played DESC, total_kills DESC
                LIMIT 3
            """,
            ) as cursor:
                top_players = await cursor.fetchall()

            if not top_players:
                await ctx.send(
                    "❌ No available players found!\n\n"
                    "**Reasons:**\n"
                    "• All players are already linked\n"
                    "• No games have been recorded yet\n\n"
                    "💡 **Try:** `!list_players unlinked` to see all unlinked players"
                )
                return

            # Build embed with top 3 options
            embed = discord.Embed(
                title="🔍 Link Your Account",
                description=(
                    f"Found **{len(top_players)}** potential matches!\n\n"
                    f"**Select your account:**\n"
                    f"• React with 1️⃣/2️⃣/3️⃣ below\n"
                    f"• Or use `!select <number>` within 60 seconds\n"
                    f"• Or use `!find_player <name>` to search"
                ),
                color=0x3498DB,
            )

            options_data = []
            for idx, (guid, last_date, kills, deaths, games) in enumerate(top_players, 1):
                # Get top 3 aliases for this GUID
                async with db.execute(
                    """
                    SELECT alias, last_seen, times_seen
                    FROM player_aliases
                    WHERE guid = ?
                    ORDER BY last_seen DESC, times_seen DESC
                    LIMIT 3
                """,
                    (guid,),
                ) as cursor:
                    aliases = await cursor.fetchall()

                # Format aliases
                if aliases:
                    primary_name = aliases[0][0]
                    alias_list = [a[0] for a in aliases[:3]]
                    alias_str = ", ".join(alias_list)
                    if len(aliases) == 1:
                        alias_str += " _(only name)_"
                else:
                    # Fallback to most recent name
                    async with db.execute(
                        """
                        SELECT player_name 
                        FROM player_comprehensive_stats 
                        WHERE player_guid = ? 
                        ORDER BY session_date DESC 
                        LIMIT 1
                    """,
                        (guid,),
                    ) as cursor:
                        name_row = await cursor.fetchone()
                        primary_name = name_row[0] if name_row else "Unknown"
                        alias_str = primary_name

                kd_ratio = kills / deaths if deaths > 0 else kills

                emoji = ["1️⃣", "2️⃣", "3️⃣"][idx - 1]
                embed.add_field(
                    name=f"{emoji} **{primary_name}**",
                    value=(
                        f"**GUID:** `{guid}`\n"
                        f"**Stats:** {kills:,} K / {deaths:,} D / **{kd_ratio:.2f}** K/D\n"
                        f"**Games:** {games:,} | **Last Seen:** {last_date}\n"
                        f"**Also known as:** {alias_str}"
                    ),
                    inline=False,
                )

                options_data.append({
                    "guid": guid,
                    "name": primary_name,
                    "kills": kills,
                    "games": games,
                })

            embed.set_footer(
                text=f"💡 Or use: !link <GUID> to link directly | Requested by {ctx.author.display_name}"
            )

            message = await ctx.send(embed=embed)

            # Add reaction emojis
            emojis = ["1️⃣", "2️⃣", "3️⃣"][:len(top_players)]
            for emoji in emojis:
                await message.add_reaction(emoji)

            # Wait for reaction
            def check(reaction, user):
                return (
                    user == ctx.author
                    and str(reaction.emoji) in emojis
                    and reaction.message.id == message.id
                )

            try:
                reaction, user = await self.bot.wait_for(
                    "reaction_add", timeout=60.0, check=check
                )

                # Get selected index
                selected_idx = emojis.index(str(reaction.emoji))
                selected = options_data[selected_idx]

                # Link the account
                await db.execute(
                    """
                    INSERT OR REPLACE INTO player_links
                    (discord_id, discord_username, et_guid, et_name, linked_date, verified)
                    VALUES (?, ?, ?, ?, datetime('now'), 1)
                """,
                    (discord_id, str(ctx.author), selected["guid"], selected["name"]),
                )
                await db.commit()

                # Success!
                await message.clear_reactions()
                success_embed = discord.Embed(
                    title="✅ Account Linked Successfully!",
                    description=f"You're now linked to **{selected['name']}**",
                    color=0x00FF00,
                )
                success_embed.add_field(
                    name="Your Stats",
                    value=f"**Games:** {selected['games']:,}\n**Kills:** {selected['kills']:,}",
                    inline=True,
                )
                success_embed.add_field(
                    name="Quick Access",
                    value="• Use `!stats` (no arguments)\n• Your stats are now tracked!",
                    inline=False,
                )
                success_embed.set_footer(text=f"GUID: {selected['guid']}")
                await ctx.send(embed=success_embed)

                logger.info(
                    f"✅ Self-link: {ctx.author} linked to {selected['name']} (GUID: {selected['guid']})"
                )

            except asyncio.TimeoutError:
                await message.clear_reactions()
                await ctx.send(
                    "⏱️ Link request timed out (60s expired).\n\n"
                    "💡 Try again with `!link` or use `!find_player <name>` to search"
                )

        except Exception as e:
            logger.error(f"Error in smart self-link: {e}", exc_info=True)
            await ctx.send(f"❌ Error during self-linking: {e}")

    async def _link_by_guid(self, ctx, discord_id: str, guid: str, db):
        """Direct GUID linking with confirmation."""
        try:
            # Check if GUID exists
            async with db.execute(
                """
                SELECT 
                    SUM(kills) as total_kills,
                    SUM(deaths) as total_deaths,
                    COUNT(DISTINCT session_id) as games,
                    MAX(session_date) as last_seen
                FROM player_comprehensive_stats
                WHERE player_guid = ?
            """,
                (guid,),
            ) as cursor:
                stats = await cursor.fetchone()

            if not stats or stats[0] is None:
                await ctx.send(
                    f"❌ GUID `{guid}` not found in database.\n\n"
                    f"💡 **Try:**\n"
                    f"   • `!find_player <name>` to search by name\n"
                    f"   • `!list_players` to browse all players\n"
                    f"   • Double-check the GUID spelling"
                )
                return

            # Get top 3 aliases
            async with db.execute(
                """
                SELECT alias, last_seen, times_seen
                FROM player_aliases
                WHERE guid = ?
                ORDER BY last_seen DESC, times_seen DESC
                LIMIT 3
            """,
                (guid,),
            ) as cursor:
                aliases = await cursor.fetchall()

            if aliases:
                primary_name = aliases[0][0]
                alias_list = [a[0] for a in aliases[:3]]
                alias_str = ", ".join(alias_list)
            else:
                # Fallback
                async with db.execute(
                    """
                    SELECT player_name 
                    FROM player_comprehensive_stats 
                    WHERE player_guid = ? 
                    ORDER BY session_date DESC 
                    LIMIT 1
                """,
                    (guid,),
                ) as cursor:
                    name_row = await cursor.fetchone()
                    primary_name = name_row[0] if name_row else "Unknown"
                    alias_str = primary_name

            kills, deaths, games, last_seen = stats
            kd_ratio = kills / deaths if deaths > 0 else kills

            # Confirmation embed
            embed = discord.Embed(
                title="🔗 Confirm Account Link",
                description=f"Link your Discord to **{primary_name}**?",
                color=0xFFA500,
            )
            embed.add_field(
                name="GUID",
                value=f"`{guid}`",
                inline=False,
            )
            embed.add_field(
                name="Known Names (top 3 aliases)",
                value=alias_str,
                inline=False,
            )
            embed.add_field(
                name="Stats",
                value=f"**{kills:,}** K / **{deaths:,}** D / **{kd_ratio:.2f}** K/D",
                inline=True,
            )
            embed.add_field(
                name="Activity",
                value=f"**{games:,}** games | Last: {last_seen}",
                inline=True,
            )
            embed.set_footer(text="React ✅ to confirm or ❌ to cancel (60s)")

            message = await ctx.send(embed=embed)
            await message.add_reaction("✅")
            await message.add_reaction("❌")

            def check(reaction, user):
                return (
                    user == ctx.author
                    and str(reaction.emoji) in ["✅", "❌"]
                    and reaction.message.id == message.id
                )

            try:
                reaction, user = await self.bot.wait_for(
                    "reaction_add", timeout=60.0, check=check
                )

                if str(reaction.emoji) == "✅":
                    # Confirmed - link it
                    await db.execute(
                        """
                        INSERT OR REPLACE INTO player_links
                        (discord_id, discord_username, et_guid, et_name, linked_date, verified)
                        VALUES (?, ?, ?, ?, datetime('now'), 1)
                    """,
                        (discord_id, str(ctx.author), guid, primary_name),
                    )
                    await db.commit()

                    await message.clear_reactions()
                    await ctx.send(
                        f"✅ Successfully linked to **{primary_name}** (GUID: `{guid}`)\n\n"
                        f"💡 Use `!stats` to see your stats!"
                    )

                    logger.info(f"✅ GUID link: {ctx.author} linked to {primary_name} (GUID: {guid})")
                else:
                    await message.clear_reactions()
                    await ctx.send("❌ Link cancelled.")

            except asyncio.TimeoutError:
                await message.clear_reactions()
                await ctx.send("⏱️ Confirmation timed out.")

        except Exception as e:
            logger.error(f"Error in GUID link: {e}", exc_info=True)
            await ctx.send(f"❌ Error linking by GUID: {e}")

    async def _link_by_name(self, ctx, discord_id: str, player_name: str, db):
        """Name search linking with fuzzy matching."""
        try:
            # Search in player_aliases first
            async with db.execute(
                """
                SELECT DISTINCT pa.guid
                FROM player_aliases pa
                WHERE LOWER(pa.alias) LIKE LOWER(?)
                ORDER BY pa.last_seen DESC
                LIMIT 5
            """,
                (f"%{player_name}%",),
            ) as cursor:
                alias_guids = [row[0] for row in await cursor.fetchall()]

            # Also search main stats table
            async with db.execute(
                """
                SELECT player_guid, player_name,
                       SUM(kills) as total_kills,
                       COUNT(DISTINCT session_id) as games,
                       MAX(session_date) as last_seen
                FROM player_comprehensive_stats
                WHERE LOWER(player_name) LIKE LOWER(?)
                GROUP BY player_guid
                ORDER BY last_seen DESC, games DESC
                LIMIT 5
            """,
                (f"%{player_name}%",),
            ) as cursor:
                matches = await cursor.fetchall()

            # Combine and deduplicate
            guid_set = set(alias_guids)
            for match in matches:
                guid_set.add(match[0])

            if not guid_set:
                await ctx.send(
                    f"❌ No player found matching **'{player_name}'**\n\n"
                    f"💡 **Try:**\n"
                    f"   • `!find_player {player_name}` for detailed search\n"
                    f"   • `!link` (no arguments) to see top players\n"
                    f"   • `!list_players` to browse all players"
                )
                return

            # Get full data for found GUIDs
            guid_list = list(guid_set)[:3]  # Limit to 3

            if len(guid_list) == 1:
                # Single match - link directly with confirmation
                await self._link_by_guid(ctx, discord_id, guid_list[0], db)
            else:
                # Multiple matches - show options
                embed = discord.Embed(
                    title=f"🔍 Multiple Matches for '{player_name}'",
                    description="React with 1️⃣/2️⃣/3️⃣ to select your account:",
                    color=0x3498DB,
                )

                options_data = []
                for idx, guid in enumerate(guid_list, 1):
                    # Get stats and aliases
                    async with db.execute(
                        """
                        SELECT SUM(kills), SUM(deaths), COUNT(DISTINCT session_id), MAX(session_date)
                        FROM player_comprehensive_stats
                        WHERE player_guid = ?
                    """,
                        (guid,),
                    ) as cursor:
                        stats = await cursor.fetchone()

                    async with db.execute(
                        """
                        SELECT alias FROM player_aliases
                        WHERE guid = ?
                        ORDER BY last_seen DESC LIMIT 3
                    """,
                        (guid,),
                    ) as cursor:
                        alias_rows = await cursor.fetchall()
                        name = alias_rows[0][0] if alias_rows else "Unknown"
                        aliases_str = ", ".join([a[0] for a in alias_rows[:3]])

                    kills, deaths, games, last_seen = stats
                    kd = kills / deaths if deaths > 0 else kills

                    emoji = ["1️⃣", "2️⃣", "3️⃣"][idx - 1]
                    embed.add_field(
                        name=f"{emoji} **{name}**",
                        value=(
                            f"**GUID:** `{guid}`\n"
                            f"**Aliases:** {aliases_str}\n"
                            f"**Stats:** {kills:,} K / {kd:.2f} K/D | {games:,} games\n"
                            f"**Last:** {last_seen}"
                        ),
                        inline=False,
                    )

                    options_data.append({
                        "guid": guid,
                        "name": name,
                        "kills": kills,
                        "games": games,
                    })

                embed.set_footer(text=f"Or use: !link <GUID> | Requested by {ctx.author.display_name}")

                message = await ctx.send(embed=embed)

                emojis = ["1️⃣", "2️⃣", "3️⃣"][:len(guid_list)]
                for emoji in emojis:
                    await message.add_reaction(emoji)

                def check(reaction, user):
                    return (
                        user == ctx.author
                        and str(reaction.emoji) in emojis
                        and reaction.message.id == message.id
                    )

                try:
                    reaction, user = await self.bot.wait_for(
                        "reaction_add", timeout=60.0, check=check
                    )
                    selected_idx = emojis.index(str(reaction.emoji))
                    selected = options_data[selected_idx]

                    await db.execute(
                        """
                        INSERT OR REPLACE INTO player_links
                        (discord_id, discord_username, et_guid, et_name, linked_date, verified)
                        VALUES (?, ?, ?, ?, datetime('now'), 1)
                    """,
                        (discord_id, str(ctx.author), selected["guid"], selected["name"]),
                    )
                    await db.commit()

                    await message.clear_reactions()
                    await ctx.send(
                        f"✅ Successfully linked to **{selected['name']}** (GUID: `{selected['guid']}`)\n\n"
                        f"💡 Use `!stats` to see your stats!"
                    )

                    logger.info(f"✅ Name link: {ctx.author} linked to {selected['name']} (GUID: {selected['guid']})")

                except asyncio.TimeoutError:
                    await message.clear_reactions()
                    await ctx.send("⏱️ Selection timed out.")

        except Exception as e:
            logger.error(f"Error in name link: {e}", exc_info=True)
            await ctx.send(f"❌ Error linking by name: {e}")

    async def _admin_link(self, ctx, target_user: discord.User, guid: str):
        """Admin linking: Link another user's Discord to a GUID."""
        try:
            # Check permissions
            if not ctx.author.guild_permissions.manage_guild:
                await ctx.send(
                    "❌ You don't have permission to link other users.\n\n"
                    "**Required:** Manage Server permission"
                )
                logger.warning(
                    f"⚠️ Unauthorized admin link attempt by {ctx.author} (ID: {ctx.author.id})"
                )
                return

            # Validate GUID format (8 hex characters)
            if len(guid) != 8 or not all(c in "0123456789ABCDEFabcdef" for c in guid):
                await ctx.send(
                    f"❌ Invalid GUID format: `{guid}`\n\n"
                    f"**GUIDs must be exactly 8 hexadecimal characters** (e.g., `D8423F90`)\n\n"
                    f"💡 **Find the GUID:**\n"
                    f"   • `!find_player {guid}` to search by name\n"
                    f"   • `!list_players` to browse all players\n"
                    f"   • Then use: `!link @user <GUID>`"
                )
                return

            target_discord_id = str(target_user.id)

            async with aiosqlite.connect(self.bot.db_path) as db:
                # Check if target already linked
                async with db.execute(
                    """
                    SELECT et_name, et_guid FROM player_links
                    WHERE discord_id = ?
                """,
                    (target_discord_id,),
                ) as cursor:
                    existing = await cursor.fetchone()

                if existing:
                    await ctx.send(
                        f"⚠️ {target_user.mention} is already linked to "
                        f"**{existing[0]}** (GUID: `{existing[1]}`)\n\n"
                        f"They need to `!unlink` first."
                    )
                    return

                # Validate GUID exists
                async with db.execute(
                    """
                    SELECT 
                        SUM(kills) as total_kills,
                        SUM(deaths) as total_deaths,
                        COUNT(DISTINCT session_id) as games,
                        MAX(session_date) as last_seen
                    FROM player_comprehensive_stats
                    WHERE player_guid = ?
                """,
                    (guid,),
                ) as cursor:
                    stats = await cursor.fetchone()

                if not stats or stats[0] is None:
                    await ctx.send(
                        f"❌ GUID `{guid}` not found in database.\n\n"
                        f"💡 Use `!find_player <name>` to search for the correct GUID."
                    )
                    return

                # Get top 3 aliases
                async with db.execute(
                    """
                    SELECT alias, last_seen, times_seen
                    FROM player_aliases
                    WHERE guid = ?
                    ORDER BY last_seen DESC, times_seen DESC
                    LIMIT 3
                """,
                    (guid,),
                ) as cursor:
                    aliases = await cursor.fetchall()

                if aliases:
                    primary_name = aliases[0][0]
                    alias_list = [a[0] for a in aliases[:3]]
                    alias_str = ", ".join(alias_list)
                else:
                    # Fallback
                    async with db.execute(
                        """
                        SELECT player_name 
                        FROM player_comprehensive_stats 
                        WHERE player_guid = ? 
                        ORDER BY session_date DESC 
                        LIMIT 1
                    """,
                        (guid,),
                    ) as cursor:
                        name_row = await cursor.fetchone()
                        primary_name = name_row[0] if name_row else "Unknown"
                        alias_str = primary_name

                kills, deaths, games, last_seen = stats
                kd_ratio = kills / deaths if deaths > 0 else kills

                # Admin confirmation embed
                embed = discord.Embed(
                    title="🔗 Admin Link Confirmation",
                    description=(
                        f"Link {target_user.mention} to **{primary_name}**?\n\n"
                        f"**Requested by:** {ctx.author.mention}"
                    ),
                    color=0xFF6B00,  # Orange for admin action
                )
                embed.add_field(
                    name="Target User",
                    value=f"{target_user.mention} ({target_user.name})",
                    inline=True,
                )
                embed.add_field(
                    name="GUID",
                    value=f"`{guid}`",
                    inline=True,
                )
                embed.add_field(
                    name="Known Names (top 3)",
                    value=alias_str,
                    inline=False,
                )
                embed.add_field(
                    name="Stats",
                    value=(
                        f"**Kills:** {kills:,} | **Deaths:** {deaths:,}\n"
                        f"**K/D:** {kd_ratio:.2f} | **Games:** {games:,}"
                    ),
                    inline=True,
                )
                embed.add_field(
                    name="Last Seen",
                    value=last_seen,
                    inline=True,
                )
                embed.set_footer(text="React ✅ (admin) to confirm or ❌ to cancel (60s)")

                message = await ctx.send(embed=embed)
                await message.add_reaction("✅")
                await message.add_reaction("❌")

                def check(reaction, user):
                    return (
                        user == ctx.author  # Only admin can confirm
                        and str(reaction.emoji) in ["✅", "❌"]
                        and reaction.message.id == message.id
                    )

                try:
                    reaction, user = await self.bot.wait_for(
                        "reaction_add", timeout=60.0, check=check
                    )

                    if str(reaction.emoji) == "✅":
                        # Confirmed - link it
                        await db.execute(
                            """
                            INSERT OR REPLACE INTO player_links
                            (discord_id, discord_username, et_guid, et_name, linked_date, verified)
                            VALUES (?, ?, ?, ?, datetime('now'), 1)
                        """,
                            (target_discord_id, str(target_user), guid, primary_name),
                        )
                        await db.commit()

                        await message.clear_reactions()

                        # Success message
                        success_embed = discord.Embed(
                            title="✅ Admin Link Successful",
                            description=(
                                f"{target_user.mention} is now linked to **{primary_name}**"
                            ),
                            color=0x00FF00,
                        )
                        success_embed.add_field(
                            name="GUID",
                            value=f"`{guid}`",
                            inline=True,
                        )
                        success_embed.add_field(
                            name="Linked By",
                            value=ctx.author.mention,
                            inline=True,
                        )
                        success_embed.set_footer(
                            text=f"💡 {target_user.name} can now use !stats to see their stats"
                        )

                        await ctx.send(embed=success_embed)

                        # Log admin action
                        logger.info(
                            f"🔗 Admin link: {ctx.author} (ID: {ctx.author.id}) "
                            f"linked {target_user} (ID: {target_user.id}) "
                            f"to GUID {guid} ({primary_name})"
                        )

                    else:
                        await message.clear_reactions()
                        await ctx.send("❌ Admin link cancelled.")

                except asyncio.TimeoutError:
                    await message.clear_reactions()
                    await ctx.send("⏱️ Admin link confirmation timed out.")

        except Exception as e:
            logger.error(f"Error in admin link: {e}", exc_info=True)
            await ctx.send(f"❌ Error during admin linking: {e}")

    @commands.command(name="unlink")
    async def unlink(self, ctx):
        """
        🔓 Unlink your Discord account from your in-game profile.

        Removes the connection between your Discord and your ET:Legacy account.
        You can re-link at any time using `!link`.

        Usage:
            !unlink

        Note:
            Your game stats are not deleted, only the Discord link is removed.
        """
        try:
            discord_id = str(ctx.author.id)

            async with aiosqlite.connect(self.bot.db_path) as db:
                # Check if linked
                async with db.execute(
                    """
                    SELECT et_name, et_guid FROM player_links
                    WHERE discord_id = ?
                """,
                    (discord_id,),
                ) as cursor:
                    existing = await cursor.fetchone()

                if not existing:
                    await ctx.send(
                        "❌ You don't have a linked account.\n\n"
                        "💡 Use `!link` to link your account!"
                    )
                    return

                player_name, guid = existing

                # Remove link
                await db.execute(
                    """
                    DELETE FROM player_links
                    WHERE discord_id = ?
                """,
                    (discord_id,),
                )
                await db.commit()

            await ctx.send(
                f"✅ Successfully unlinked from **{player_name}** (GUID: `{guid}`)\n\n"
                f"💡 Your stats are still saved. Use `!link` to re-link anytime!"
            )

            logger.info(f"🔓 Unlink: {ctx.author} unlinked from {player_name} (GUID: {guid})")

        except Exception as e:
            logger.error(f"Error in unlink command: {e}", exc_info=True)
            await ctx.send(f"❌ Error unlinking account: {e}")

    @commands.command(name="select")
    async def select_option(self, ctx, selection: Optional[int] = None):
        """
        🔢 Select an option from a link prompt (alternative to reactions).

        This command provides a text-based alternative to clicking reaction emojis.
        Must be used within 60 seconds of a `!link` command showing options.

        Usage:
            !select <1-3>

        Args:
            selection: Option number (1, 2, or 3)

        Examples:
            !select 1  → Select first option
            !select 2  → Select second option

        Note:
            Currently requires using reactions on the link message.
            Future update will add persistent selection state.
        """
        if selection is None:
            await ctx.send(
                "❌ Please specify a number!\n\n"
                "**Usage:** `!select 1`, `!select 2`, or `!select 3`\n\n"
                "💡 This works with link prompts that show 1️⃣/2️⃣/3️⃣ reactions"
            )
            return

        if selection not in [1, 2, 3]:
            await ctx.send("❌ Please select 1, 2, or 3.")
            return

        await ctx.send(
            f"💡 You selected option **{selection}**!\n\n"
            f"**Note:** The `!select` command currently requires integration "
            f"with the link workflow.\n\n"
            f"**For now:**\n"
            f"• Use the reaction emojis (1️⃣/2️⃣/3️⃣) on the link message\n"
            f"• Or use `!link <GUID>` to link directly\n"
            f"• Or use `!find_player <name>` to find GUIDs\n\n"
            f"**Tip:** React to the message above within 60 seconds!"
        )

        # TODO: Implement persistent selection state
        # This would require storing pending link requests per user
        # and checking if they have an active selection window


async def setup(bot):
    """Load the Link Cog."""
    await bot.add_cog(LinkCog(bot))
